#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 17 is required but Java was not found." >&2
  exit 1
fi

JAVA_MAJOR="$(java -version 2>&1 | sed -n '1s/.*version "\([0-9]*\).*/\1/p')"
if [ "$JAVA_MAJOR" != "17" ]; then
  echo "ERROR: Java 17 is required. Current Java major version: ${JAVA_MAJOR:-unknown}" >&2
  exit 1
fi

chmod +x gradlew
./gradlew clean lint testDebugUnitTest assembleDebug --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "ERROR: Build finished without producing $APK" >&2
  exit 1
fi

cp "$APK" "Periodic-v2.3-debug.apk"
echo
echo "================================================"
echo " PERIODIC 2.3 DEBUG BUILD COMPLETED"
echo "================================================"
echo "APK: $(pwd)/Periodic-v2.3-debug.apk"
